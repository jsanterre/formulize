formulize-plugin
================

Plugin for the integration of Formulize into Joomla.

It takes care of the user and group synchronization between the two systems, after the initial synchronization made by the component. 

It also takes care of the single sign-on.

For full functionality, it needs to be installed with formulize-joomla. 

Those two parts will be combined at a later point in one single package.

***Note to Julian***

There's two ways to install the two extensions: 

First method:
 
1. Zip formulize-joomla directory and zip formulize-plugin directory
2. Browse to the zipped formulize-joomla using Upload Package File 
3. Hit upload and install
4. Browse to the zipped formulize-plugin using Upload Package File 
5. Hit upload and install

or 

Second method:  (***SIMPLER***)

1. Copy your path to the directory formulize-joomla (including formulize-joomla at the end) in Install from Directory
2. Hit install
3. Copy your path to the directory formulize-plugin (including formulize-plugin at the end) in Install from Directory
4. Hit install

*************Note that a lot of debugging messages are still displaying in the plugin. 

*************I am keeping them to test the new user mapping table we will have soon...

*************This version is working with the latest version of the API


